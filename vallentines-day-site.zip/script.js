
const start=new Date('2026-02-01T00:00:00');
function update(){
 const now=new Date();
 const diff=now-start;
 const days=Math.floor(diff/86400000);
 const hours=Math.floor((diff%86400000)/3600000);
 const mins=Math.floor((diff%3600000)/60000);
 document.getElementById('timer').innerText=`${days} dias, ${hours} horas e ${mins} minutos`;
}
setInterval(update,1000); update();

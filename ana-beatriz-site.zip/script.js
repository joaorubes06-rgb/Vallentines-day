const target=new Date('2026-02-01T00:00:00');
function update(){
const now=new Date();
const diff=target-now;
const d=Math.floor(diff/1000/60/60/24);
document.getElementById('countdown').innerText=d+' dias restantes';
}
update();setInterval(update,1000);
